function t = n2c(pts)
% N2C  t = num2cell(pts,1)
t = num2cell(pts,1);
end