%ZIPREQFILES_TEST
fname = 'eumA2five_test2.m';
expression = 'interp*';
zipfname = 'eumA2five_test2_201201';
[fpathshort,nameExt,plist,fnames] = zipreqfiles(fname,expression,zipfname,'removefname',false);